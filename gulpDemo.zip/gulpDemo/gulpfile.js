/**
 * Created by wangxl01 on 2016/7/29.
 */
//导入工具包 require('node_modules里对应模块')
var gulp = require('gulp'), //本地安装gulp所用到的地方
  uglify = require('gulp-uglify'), //压缩多个js文件
  concat = require('gulp-concat'), //使用gulp-concat合并javascript文件，减少网络请求
  cssmin = require('gulp-minify-css'), //gulp-minify-css压缩css文件
  cssver = require('gulp-make-css-url-version'), //给css文件里引用url加版本号（根据引用文件的md5生产版本号）
  rev = require('gulp-rev-append'), //使用gulp-rev-append给页面的引用添加版本号，清除页面引用缓存
  autoprefixer = require('gulp-autoprefixer'),
  livereload = require('gulp-livereload'),
  cheerio = require('gulp-cheerio'), //重新构建index.html
  babel = require('gulp-babel')
  less=require('gulp-less'),
  imagemin = require('gulp-imagemin');
  pngquant = require('imagemin-pngquant');
  rename = require('gulp-rename')
 cssnano = require('gulp-cssnano')
/* browserSnyc=require('browser-snyc').create(),//Browsersync能让浏览器实时、快速响应您的文件更改（html、js、css、sass、less等）http://www.browsersync.cn/
 reload = browserSnyc.reload;*/


// 基本使用（给页面引用url添加版本号，以清除页面缓存）
//gulp-rev-append 插件将通过正则(?:href|src)=”(.*)[?]rev=(.*)[“]查找并给指定链接填加版本号（默认根据文件MD5生成，因此文件未发生改变，此版本号将不会变）
gulp.task('testrev', function () {
  gulp.src('index.html')
     .pipe(rev())
    .pipe(gulp.dest('dist/html'))
});
//编译lessr
//gulp-livereload拯救F5！当监听文件发生变化时，浏览器自动刷新页面。【事实上也不全是完全刷新，例如修改css的时候，不是整个页面刷新，而是将修改的样式植入浏览器，非常方便。】特别是引用外部资源时，刷新整个页面真是费时费力。
gulp.task('testreload',function(){
    gulp.src('less/*.less')
        .pipe(less())//该任务调用的模块
         .pipe(concat('style.css')) //拼接成一个文件，并命名为style.css
           .pipe(cssnano()) //如果使用cssnano需要在autoprefix之前调用，否则后者无效
           .pipe(autoprefixer({ //自动添加兼容浏览器的样式前缀，例如：-webkit-, -mo-
             browsers: ['last 2 versions'],
             cascade: false
           }))
           .pipe(rename({ //重命名为style.min.css
             suffix: '.min'
           }))
        //.pipe(livereload())
        .pipe(gulp.dest('dist/css'))

});

//使用gulp-imagemin压缩图片文件（包括PNG、JPEG、GIF和SVG图片），很多人安装gulp-imagemin都会出现错误，我也查了很多资料，也不知道所以然，我的做法是出错再重新安装，如果你知道问题所在，请一定告诉我！
gulp.task('testimagesmin', function () {
  gulp.src('images/*.*')
    .pipe(imagemin({
          use: [pngquant()] //使用pngquant深度压缩png图片的imagemin插件
          
        }))
    .pipe(gulp.dest('dist/images'))
});
gulp.task('testjs', function () {
  gulp.src('js/*.js')
    // .pipe(babel({presets: ['es2015']})) // es5检查机制
    .pipe(uglify({
      mangle: true, //类型：Boolean 默认：true 是否修改变量名 mangle: {except: ['require' ,'exports' ,'module' ,'$']}//排除混淆关键字
      compress: true, //类型：Boolean 默认：true 是否完全压缩
      preserveComments: 'all' //保留所有注释
    }))
    .pipe(concat('gulp.min.js')) //合并后的文件名
    .pipe(gulp.dest('dist/js'));
});

gulp.task('testcss', function () {
  gulp.src('css/*.css')
    .pipe(cssmin({
      advanced: false, //类型：Boolean 默认：true [是否开启高级优化（合并选择器等）]
      compatibility: 'ie7', //保留ie7及以下兼容写法 类型：String 默认：''or'*' [启用兼容模式； 'ie7'：IE7兼容模式，'ie8'：IE8兼容模式，'*'：IE9+兼容模式]
      keepBreaks: true, //类型：Boolean 默认：false [是否保留换行]
      keepSpecialComments: '*' //保留所有特殊前缀 当你用autoprefixer生成的浏览器前缀，如果不加这个参数，有可能将会删除你的部分前缀
    }))
    .pipe(autoprefixer({
      browsers: ['last 2 versions', 'Android >=4.0'],
      cascade: true, //是否美化属性值 默认：true 像这样：
      //-webkit-transform: rotate(45deg);
      //        transform: rotate(45deg);
      remove: true //是否去掉不必要的前缀 默认：true

    }))
    .pipe(cssver()) //给css文件里引用文件加版本号（文件MD5）
    .pipe(concat('gulp.min.css')) //合并后的文件名
    .pipe(gulp.dest('dist/css')); //保存路径
});

gulp.task('default', ['testrev', 'testjs', 'testcss', 'testreload', 'testimagesmin']);