$(function () {
  'use strict';

  //下拉刷新页面
  $(document).on("pageInit", "#page-voucher", function(e, id, page) {
   // 加载flag
      var loading = false;
      // 最多可加载的条目
      var maxItems = 100;

      // 每次加载添加多少条目
      var itemsPerLoad =5;

      function addItems(number, lastIndex) {
              // 生成新条目的HTML
              var html = '';
              for (var i = lastIndex + 1; i <= lastIndex + number; i++) {
                  html += "<div class='ui-voucher-line '>"
				  +"<div class='ui-voucher-one ui-voucher-hot clearfix'>"
                  +"<div class='ui-col-85 fr box-size-b v-pad-l '>"
                  +"<div class='voucher-line clearfix '><div class='voucher-money v-font1'><p>¥120</p></div>"
                  +"<div class='voucher-info'> <p>在线订单</p><p>单笔满100减999</p></div></div></div>"
                 +" <div class='ui-col-15 fr ui-dashe box-size-b v-pad-l '><div class='ui-center receive'><div class='v-take-use'>立即领取</div></div></div></div>"
          +" <div class='v-take clearfix'><div class='v-take-con clearfix '> <span class='v-time'>有效期<i class='time-start'>2015.05.27</i>－<i class='time-end'>2015.06.30</i></span>"
           +" <span class='v-tip'>使用须知<i class='iconfont v-tip-icon'>&#xe602;</i></span> </div></div>"
           +" <div class='tipcontent'> <p>1.仅限本小区团购商品</p> <p>2.不可用品类：护理饮品饮料居家日用厨房调味冷 冻冷藏素</p></div><div class='voucher-q'> <img src='images/quan.png'></div></div>";
              }
              // 添加新条目
              $('.infinite-scroll-bottom .list-container').append(html);

          }
          //预先加载20条
      addItems(itemsPerLoad, 0);

      // 上次加载的序号

      var lastIndex = 20;

      // 注册'infinite'事件处理函数
      $(document).on('infinite', '.infinite-scroll-bottom',function() {
          // 如果正在加载，则退出
          if (loading) return;

          // 设置flag
          loading = true;

          // 模拟1s的加载过程
          setTimeout(function() {
              // 重置加载flag
              loading = false;

              if (lastIndex >= maxItems) {
                  // 加载完毕，则注销无限加载事件，以防不必要的加载
                  $.detachInfiniteScroll($('.infinite-scroll'));
                  // 删除加载提示符
                  $('.infinite-scroll-preloader').remove();
                  return;
              }

              // 添加新条目
              addItems(itemsPerLoad, lastIndex);
              // 更新最后加载的序号
              lastIndex = $('.list-container li').length;
              //容器发生改变,如果是js滚动，需要刷新滚动
              $.refreshScroller();
          }, 1000);
      });
  });
  });
